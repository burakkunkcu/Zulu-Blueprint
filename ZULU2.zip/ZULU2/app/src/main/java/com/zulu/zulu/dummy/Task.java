package com.zulu.zulu.dummy;

/**
 * Created by Ahmet Burak on 20.4.2016.
 */
public class Task {
}
